#ifndef _MACRO_
#define _MACRO_

#define HASH_LENGTH 256
#define TXNID_LENGTH 32

#define CSV_INPUTS_PATH "d:/data/2023.10.7/lab2/csv/inputs.csv"
#define CSV_BLOCK_PATH "d:/data/2023.10.7/lab2/csv/blocks.csv"
#define CSV_OUTPUTS_PATH "d:/data/2023.10.7/lab2/csv/outputs.csv"
#define CSV_TRANSACTIONS_PATH "d:/data/2023.10.7/lab2/csv/transactions.csv"

#define int64 int64_t
#define int int32_t

#endif