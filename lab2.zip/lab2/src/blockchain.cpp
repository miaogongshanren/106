#include "blockchain.h"

block *initBlock(int64 height, char *hash, char *prevHash, char *merkleRoot, int64 nonce, int64 *transactions) {
    block *newBlock = (block *)malloc(sizeof(block));
    newBlock->hash = (char *)malloc(HASH_LENGTH);
    strcopy(newBlock->hash, hash, HASH_LENGTH);

    newBlock->prevHash = (char *)malloc(HASH_LENGTH);
    strcopy(newBlock->prevHash, prevHash, HASH_LENGTH);

    newBlock->merkleRoot = nullptr;

    newBlock->nonce = 0x3f3f3f3f;

    newBlock->transactions = transactions;

    newBlock->prev = nullptr;
    newBlock->next = nullptr;
    // printf("done\n");

    return newBlock;
}

void strcopy(char *dest, char *source, int length) {
    int i = 0;
    while (source[i] != '\0' && i < length) {
        if (source[i] != '\0') {
            dest[i] = source[i];
        } else {
            dest[i] = '\0';
        }
        ++i;
    }
}