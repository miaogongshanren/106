#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include "blockchain.h"
#include "marco.h"
#include "minicsv.h"

static void display_cols(char* const* const cols, const size_t cols_count) {
    size_t i = (size_t)0U;

    while (i < cols_count) {
        if (i != (size_t)0U) {
            putchar('\t');
        }
        printf("[%s]", cols[i]);
        i++;
    }
    putchar('\n');
}



int main(void) {
    FILE* fp = fopen(CSV_BLOCK_PATH, "r");
    if (fp == NULL) {
        perror("fopen");
        return -1;
    }
    fseek(fp, 0, SEEK_END);
    int file_size = ftell(fp) * sizeof(char);
    char* buf = (char*)malloc(file_size);
    memset(buf, '\0', file_size);
    fseek(fp, 0, SEEK_SET);
    fread(buf, sizeof(char), file_size, fp);
    fclose(fp);

    char* cols[5];

    char* r = buf;
    size_t cols_count;

    r = minicsv_parse_line(buf, cols, &cols_count, sizeof cols / sizeof cols[0]);
    if (cols_count > sizeof cols / sizeof cols[0]) {
        abort();
    }
    display_cols(cols, cols_count);

    printf("Columns:\n");
    printf("%d\n", sizeof(block));

    block* rootBlock = (block*)malloc(sizeof(block));
    block* prevBlock = rootBlock;

    printf("BlockSize:%d\n", sizeof(block));

    while (r[0] != '\0') {
        r = minicsv_parse_line(r, cols, &cols_count, sizeof cols / sizeof cols[0]);
        if (cols_count > sizeof cols / sizeof cols[0]) {
            abort();
        }

        block* newBlock = initBlock((int64)(cols[0] - 0), cols[1], cols[2], cols[3], (int64)(cols[4] - 0), nullptr);
        prevBlock->next = newBlock;
        prevBlock = newBlock;

        display_cols(cols, cols_count);
    }

    rootBlock = rootBlock->next;
    while (rootBlock != nullptr) {
        printf("block hash: %s\n", rootBlock->hash);
        rootBlock = rootBlock->next;
    }

    printf("Remainder: [%s]\n", r);

    return 0;
}
