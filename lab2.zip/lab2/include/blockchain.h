#ifndef _BLOCKCHAIN_
#define _BLOCKCHAIN_

#include <stdio.h>
#include <stdlib.h>
#include<stdint.h>

#include "marco.h"

typedef struct block {
    int64 height;
    char *hash;
    char *prevHash;
    char *merkleRoot;

    int64 nonce;

    int64 *transactions;

    struct block *prev;
    struct block *next;
} block;

typedef struct transaction {
    char *txid;
    int64 input_count;
    int64 output_count;
    int64 *inputs;
    int64 *outputs;
    int is_coinbase;
} transaction;

typedef struct input {
    int64 pre_block;
    int64 prevTxID;
    int64 prevTxOutIndex;
    char *scriptSig = nullptr;
} input;

typedef struct output {
    int64 txid;
    int64 index;
    int64 values;
    char *script = nullptr;
} output;

block *initBlock(int64 height, char *hash, char *prevHash, char *merkleRoot, int64 nonce, int64 *transaction);
void strcopy(char *dest, char *source, int length);
#endif